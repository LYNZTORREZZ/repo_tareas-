import tkinter as tk
from tkinter import messagebox


class Aplicacion:
    def __init__(self, ventana):
        self.ventana = ventana
        self.ventana.configure(bg="pink")
        self.ventana.title("Inicio")
        self.ventana.geometry("500x750")  # Aumentado el alto para que quepa toda la nueva información
        
        try:
            self.ventana.iconbitmap("manos.ico")
        except Exception:
            pass

        self.etiqueta_nombre = tk.Label(
            self.ventana,
            text="Lynz Yhenedy Torrez Quiroz",
            font="Helvetica 28 bold",
            bg="pink",
            fg="black"
        )
        self.etiqueta_nombre.pack(pady=5)

        self.etiqueta_edad = tk.Label(
            self.ventana,
            text="Edad: 19 años",
            font="arial 14 bold",
            bg="pink",
            fg="gray"
        )
        self.etiqueta_edad.pack(pady=10)

        self.etiqueta_estudios = tk.Label(
            self.ventana,
            text="Estudio ing.Sistemas",
            font="arial 14 bold",
            bg="pink",
            fg="black"
        )
        self.etiqueta_estudios.pack(pady=5)

        self.etiqueta_gustos = tk.Label(
            self.ventana,
            text="Me gusta: dibujar, Dormir, escuchar musica,ir de viaje",
            font="arial 14 bold",
            bg="pink",
            fg="blue"
        )
        self.etiqueta_gustos.pack(pady=5)

        self.etiqueta_musica = tk.Label(
            self.ventana,
            text="mi artista favorito Chester bennington , TR1, DUKI,",
            font="arial 14 bold",
            bg="pink",
            fg="purple"
        )
        self.etiqueta_musica.pack(pady=5)

        self.etiqueta_anime = tk.Label(
            self.ventana,
            text="Objetivo de vida: Dominar las herramientas tecnológicas para crear proyectos que ayuden a la sociedad.",
            font="arial 11 bold",
            bg="pink",
            fg="darkgreen"
        )
        self.etiqueta_anime.pack(pady=5)

        try:
            self.imagen = tk.PhotoImage(file="XD.png").subsample(3, 3)
            self.image = tk.Label(self.ventana, image=self.imagen, bg="pink")
            self.image.pack(pady=15)
        except Exception:
            self.image = tk.Label(
                self.ventana, 
                text="(Falta el archivo de la imagen en esta carpeta)", 
                bg="pink", 
                fg="white"
            )
            self.image.pack(pady=15)


ventana = tk.Tk()
app = Aplicacion(ventana)
ventana.mainloop()